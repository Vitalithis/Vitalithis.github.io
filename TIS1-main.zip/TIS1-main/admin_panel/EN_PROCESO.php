<div class="container">
    <h1>PROXIMAMENTE</h1>
    <img src="ENPROCESAO.svg" alt="">
</div>

<style>
    .container {
        display: flex; /* Coloca los elementos en línea */
        align-items: center; /* Alinea verticalmente al centro */
    }

    .container h1 {
        margin-right: 10px; /* Espacio entre el encabezado y la imagen */
    }
</style>
        <!-- Botón de Volver al panel de administración -->
        <div class="mb-4">
        <button onclick="window.location.href='../index.php'" class="btn btn-secondary">Volver al menú principal</button>
        <button onclick="history.back()">Volver Atrás</button>

    </div>

